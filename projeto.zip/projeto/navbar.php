﻿
	<!--<style type="text/css">
		.opmenu{font-size:16px; font-weight:bold;}
		
		.navbar-default{border-bottom:2px solid; border-color:#5001d8; border-radius:0px; background-color:#6199fd;}
		
		.navbar-nav{font-size:16px; font-family:'Comic Sans MS';}
	</style>-->

<nav class="navbar navbar-default navbar-fixed-top" style="margin-bottom:0px;">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="index.php" style="font-size:28px;">TimTimToys.com</a>
			</div>
			<div>
				<ul class="nav navbar-nav navbar-right">
					<li><a href="index.php" class="opmenu">Home</a></li>
					<li><a href="category.php" class="opmenu">Categorias</a></li>
					<li><a href="admin.php" class="opmenu">Administração</a></li>
					<li><a href="about.php" class="opmenu">Sobre o Site</a></li>
				</ul>
			</div>
		</div>
	</nav>